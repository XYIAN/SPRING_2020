package Interface;

interface ItemOne{
    ItemOne(){//constructor here
    
        
    }
    //
    int activate();    
}
