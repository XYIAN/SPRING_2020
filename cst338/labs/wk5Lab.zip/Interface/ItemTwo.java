package Interface;

interface ItemTwo{
    int deactivate();
    ItemTwo(){
        //CONSTRUCTOR 
    }
}