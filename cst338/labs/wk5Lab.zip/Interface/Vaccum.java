package Interface;

public class Vaccum{
    boolean on = true; 
    //constructor 
    Vaccum(){on = false; }
}